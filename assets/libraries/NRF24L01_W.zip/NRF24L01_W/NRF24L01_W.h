/**
 * @file NRF24L01_W.h
 * @author Orion Serup (oserup@proton.me)
 * @brief Contains the Declarations and definitions for the NRF24L01_W library
 * @version 0.1
 * @date 2023-01-02
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#pragma once 

#ifndef NRFL01_H
#define NRFL01_H

#include "RF24.h"

struct WeatherReport {
  uint8_t temperature;
  uint8_t humidity;
  uint8_t light;
};

struct RemoteData {
  uint8_t vx;
  uint8_t vy;
  uint8_t sw;
};

/// @brief Class Representing the NRF module
class NRF24L01_W {

public:

    /**
     * @brief Construct a new NRF24L01_W object
     * 
     * @param ce_pin: Chip Enable Pin Number 
     * @param cs_pin: Chip Select Pin Number 
     */
    NRF24L01_W(const int ce_pin, const int cs_pin);

    /**
     * @brief Starts the Radio 
     * 
     * @return true: If the Radio Started correctly 
     * @return false: If the Radio failed to start
     */
    bool begin();

    /**
     * @brief Set the Recieving Address
     * 
     * In Receive Mode this is the address of the transmitter that we want to receive from
     * In Transmit Mode this is the Address of the device we are sending from 
     * 
     * @param address: 5 character address, only 5 characters
     */
    void setReceiveAddress(const char* address);

    /**
     * @brief Set the Transmit Address
     *  
     * In Transmit Mode this corresponds to the address that we want to write to with our transmissions
     * In Receive mode this corresponds to the device's address
     * 
     * @param address: 5 character address, only 5 characters
     */
    void setTransmitAddress(const char* address);

    /**
     * @brief Set the channel
     *  
     * There are 125 channels in which the radios may communicate. The radios must be on the same channel
     * 
     * @param channel: 0-124
     */
    void NRF24L01_W::setChannel(uint8_t channel);

    /**
     * @brief Reads how many bytes are available in the buffers for recieving
     * @note Needs to be in Receiving mode for this to work
     * @return int: Number of bytes available to read, -1 if we are transmitting
     */
    int available();
    
    /**
     * @brief Sends data targetting the Reciever with the addreess matching the Transmit Address
     * @note: Needs to be in Transmit mode for this to work
     * @param buffer: data buffer to send, WeatherReport type
     * @return bool: If the buffer was sent
     */
    bool write(const WeatherReport& buffer);

        /**
     * @brief Sends data targetting the Reciever with the addreess matching the Transmit Address
     * @note: Needs to be in Transmit mode for this to work
     * @param buffer: data buffer to send, RemoteData type
     * @return bool: If the buffer was sent
     */
    bool write(const RemoteData& buffer);


    /**
     * @brief Reads data from a Transmitter
     * @note Needs to be in Receive Mode to work
     * @returns true if data was read, false if not
     */
    WeatherReport read();

    /**
     * @brief Reads data from a Transmitter
     * @note Needs to be in Receive Mode to work
     * @returns true if data was read, false if not
     */
    RemoteData readRemoteData();


private:

    RF24 rf24; // inner manager component, does the actual heavy lifting

};

#endif
