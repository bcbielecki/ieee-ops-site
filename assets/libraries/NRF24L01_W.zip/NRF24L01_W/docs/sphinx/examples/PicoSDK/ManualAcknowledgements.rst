manualAcknowledgements
==========================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/manualAcknowledgements.cpp
    :caption: examples_pico/manualAcknowledgements.cpp
    :linenos:
