interruptConfigure
======================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/interruptConfigure.cpp
    :caption: examples_pico/interruptConfigure.cpp
    :linenos:
