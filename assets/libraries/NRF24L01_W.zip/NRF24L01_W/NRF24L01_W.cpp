/**
 * @file NRFL01.cpp
 * @author Orion Serup (oserup@proton.me)
 * @brief Contains the Implentation for the NRF24L01_W Functionality
 * @version 0.1
 * @date 2023-01-26
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include "NRF24L01_W.h"

NRF24L01_W::NRF24L01_W(const int ce_pin, const int cs_pin) : rf24(ce_pin, cs_pin) {}

bool NRF24L01_W::begin() {

    bool began = rf24.begin();

    if(began) { // if we are connected and started

        rf24.setPALevel(RF24_PA_HIGH); // set the power level
        rf24.enableDynamicPayloads(); // have the packet size be determined per packet

    }

    return began;

}

void NRF24L01_W::setReceiveAddress(const char* const address)  {

    rf24.openReadingPipe(1, (const uint8_t*)address); // set the first reading address
    rf24.startListening();
}


void NRF24L01_W::setTransmitAddress(const char* const address)  {

    rf24.openWritingPipe((const uint8_t*)address); // set the writing address
}

void NRF24L01_W::setChannel(uint8_t channel)  {

    rf24.setChannel(channel); // set the RF24 channel (0-124)
}


bool NRF24L01_W::write(const WeatherReport& buffer) {
    rf24.stopListening(); // turn off receiving
    // rf24.flush_rx(); // throw away any unrecieved buffered data
    
    bool results = rf24.write(&buffer, sizeof(WeatherReport)); // write the data

    // rf24.flush_tx(); // throw away buffered transmision data
    rf24.startListening(); // start receiving data

    return results;
}

bool NRF24L01_W::write(const RemoteData& buffer) {
    rf24.stopListening(); // turn off receiving
    // rf24.flush_rx(); // throw away any unrecieved buffered data
    
    bool results = rf24.write(&buffer, sizeof(RemoteData)); // write the data

    // rf24.flush_tx(); // throw away buffered transmision data
    rf24.startListening(); // start receiving data

    return results;
}

int NRF24L01_W::available() {

    return rf24.available()? rf24.getPayloadSize(): 0; // get the payload size if there is one

}

WeatherReport NRF24L01_W::read() {
    WeatherReport buffer;
    rf24.read(&buffer, sizeof(WeatherReport)); // read into the buffer
    return buffer; // we read

}

RemoteData NRF24L01_W::readRemoteData() {
    RemoteData buffer;
    rf24.read(&buffer, sizeof(RemoteData)); // read into the buffer
    return buffer; // we read

}
